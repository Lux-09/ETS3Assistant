package com.ets3assistant.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ets3", MODE_PRIVATE) }
    private val projectionRequest = 41
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(Color.rgb(16,19,24)) }
        fun title(t: String, size: Float = 22f) = TextView(this).apply { text=t; textSize=size; setTextColor(Color.WHITE); setPadding(0, 8, 0, 12) }
        root.addView(title("欧洲卡3插件", 28f))
        root.addView(title("ETS3 Assistant · v0.7.1 全屏识别测试版", 14f).apply { setTextColor(0xffaeb7c4.toInt()) })
        status = title("状态：未启动", 14f); root.addView(status)
        root.addView(title("驾驶提醒开关", 18f))
        toggle(root, "超速呼吸灯", "speed_light", true)
        toggle(root, "超速提示音", "speed_sound", true)
        toggle(root, "超速顶部提示", "speed_pill", true)
        toggle(root, "燃油不足呼吸灯", "fuel_light", true)
        toggle(root, "燃油不足提示音", "fuel_sound", true)
        toggle(root, "燃油不足顶部提示", "fuel_pill", true)
        toggle(root, "疲劳驾驶呼吸灯", "fatigue_light", true)
        toggle(root, "疲劳驾驶提示音", "fatigue_sound", true)
        toggle(root, "疲劳驾驶顶部提示", "fatigue_pill", true)
        toggle(root, "悬浮球/顶部胶囊", "bubble", true)
        root.addView(title("当前手动限速（km/h）", 18f))
        numberSetting(root, "超速提醒阈值", "manual_limit", 120)
        numberSetting(root, "低油量提醒阈值（%）", "fuel_threshold", 15)
        root.addView(title("本版本不识别道路或限速牌，超速判断使用你设置的手动限速。速度与燃油识别仍需在实际游戏画面中校准；请勿作为真实驾驶安全依据。", 12f).apply { setTextColor(0xffffc66d.toInt()) })
        val start = Button(this).apply { text="启动悬浮辅助"; setOnClickListener { startOverlay() } }
        root.addView(start)
        val stop = Button(this).apply { text="停止悬浮辅助"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)); status.text="状态：已停止" } }
        root.addView(stop)
        val capture = Button(this).apply { text="授权屏幕采集并启动全屏识别"; setOnClickListener { requestCapture() } }
        root.addView(capture)
        val test = Button(this).apply { text="立即触发测试提醒（声音/呼吸灯/顶部提示）"; setOnClickListener { startOverlay(); android.os.Handler(mainLooper).postDelayed({ sendBroadcast(Intent(OverlayService.ACTION_TEST_ALERT).setPackage(packageName)); status.text="状态：已发送测试提醒" }, 500) } }
        root.addView(test)
        root.addView(title("疲劳计时仅在连续识别到游戏画面中的速度数字后开始；返回菜单或退出游戏时暂停。全屏数字识别仍需实机验证，可能误读画面中的其他数字。", 12f).apply { setTextColor(0xffffc66d.toInt()) })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun toggle(parent: LinearLayout, label: String, key: String, default: Boolean) {
        val sw = Switch(this).apply { text=label; textSize=15f; setTextColor(Color.WHITE); isChecked=prefs.getBoolean(key, default); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
        parent.addView(sw)
    }
    private fun numberSetting(parent: LinearLayout, label: String, key: String, default: Int) {
        val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=android.view.Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text=label; setTextColor(Color.WHITE); textSize=14f }, LinearLayout.LayoutParams(0, -2, 1f))
        val input = EditText(this).apply { setText(prefs.getInt(key, default).toString()); setTextColor(Color.WHITE); setSingleLine(); inputType=android.text.InputType.TYPE_CLASS_NUMBER; setEms(4) }
        input.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) { val n=input.text.toString().toIntOrNull(); if (n != null && n in 10..160) prefs.edit().putInt(key,n).apply() } }
        row.addView(input); parent.addView(row)
    }
    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            status.text="状态：请先允许显示在其他应用上层，然后再次启动"; return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        status.text="状态：悬浮辅助已启动；屏幕识别需单独授权"
    }
    private fun requestCapture() {
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), projectionRequest)
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if (requestCode==projectionRequest && resultCode==RESULT_OK && data!=null) {
            // Consent is intentionally not persisted. A production capture service must receive this token immediately.
            val capture = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(capture) else startService(capture)
            status.text="状态：屏幕采集已启动；速度与燃油识别正在运行，需真机校准"
        }
    }
}
