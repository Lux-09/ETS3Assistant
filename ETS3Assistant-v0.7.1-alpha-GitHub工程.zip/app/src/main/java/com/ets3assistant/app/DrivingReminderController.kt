package com.ets3assistant.app

import android.content.Context

/** Small, testable state controller for fatigue and fuel reminder debouncing. */
class DrivingReminderController(context: Context) {
    private val prefs = context.getSharedPreferences("ets3", Context.MODE_PRIVATE)
    private var lowFuelSamples = 0
    private var lastFuelAlertAt = 0L
    private var fatigueAlerted = false
    private var lastTick = System.currentTimeMillis()
    private var accumulatedMs = prefs.getLong("driving_elapsed_ms", 0L)

    data class Result(val fatigueDue: Boolean = false, val fuelDue: Boolean = false)

    @Synchronized fun onFuelPercent(percent: Int, now: Long = System.currentTimeMillis()): Result {
        if (percent !in 0..100) return Result()
        val threshold = prefs.getInt("fuel_threshold", 15).coerceIn(1, 50)
        if (percent <= threshold) lowFuelSamples++ else lowFuelSamples = 0
        val due = lowFuelSamples >= 3 && now - lastFuelAlertAt >= 5 * 60_000L
        if (due) { lastFuelAlertAt = now; lowFuelSamples = 0 }
        return Result(fuelDue = due)
    }

    @Synchronized fun setGameActive(active: Boolean) {
        // Driving time accrues only while a stable gameplay speed readout is present.
        prefs.edit().putBoolean("fatigue_timer_running", active).apply()
        lastTick = System.currentTimeMillis()
    }

    @Synchronized fun tick(now: Long = System.currentTimeMillis()): Result {
        val delta = (now - lastTick).coerceIn(0L, 5_000L)
        lastTick = now
        if (prefs.getBoolean("fatigue_timer_running", false)) {
            accumulatedMs += delta
            prefs.edit().putLong("driving_elapsed_ms", accumulatedMs).apply()
        }
        val due = accumulatedMs >= 30 * 60_000L && !fatigueAlerted
        if (due) fatigueAlerted = true
        return Result(fatigueDue = due)
    }

    @Synchronized fun resetFatigue() {
        accumulatedMs = 0L; fatigueAlerted = false; lastTick = System.currentTimeMillis()
        prefs.edit().putLong("driving_elapsed_ms", 0L).putBoolean("fatigue_timer_running", false).apply()
    }

    @Synchronized fun pauseFatigue(paused: Boolean) {
        lastTick = System.currentTimeMillis()
        prefs.edit().putBoolean("fatigue_timer_running", !paused).apply()
    }

    @Synchronized fun elapsedMinutes(): Long = accumulatedMs / 60_000L
}
