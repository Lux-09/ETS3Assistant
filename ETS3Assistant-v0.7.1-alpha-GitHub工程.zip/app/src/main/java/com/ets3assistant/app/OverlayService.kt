package com.ets3assistant.app

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import java.util.Locale

class OverlayService : Service(), TextToSpeech.OnInitListener {
    companion object { const val ACTION_TEST_ALERT = "com.ets3assistant.app.TEST_ALERT" }
    private lateinit var wm: WindowManager
    private val views = mutableListOf<View>()
    private val prefs by lazy { getSharedPreferences("ets3", MODE_PRIVATE) }
    private var pill: TextView? = null
    private var leftEdge: View? = null
    private var rightEdge: View? = null
    private var animator: ValueAnimator? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var reminders: DrivingReminderController
    private var activeAlerts = mutableSetOf<String>()
    private var pillAlertType: String? = null
    private var currentDetectedLimit = -1
    private var currentLimitSource = "手动默认限速"
    private var fuelPillHideRunnable: Runnable? = null
    private val fatigueTicker = object : Runnable { override fun run() { val result = reminders.tick(); if (result.fatigueDue) trigger("fatigue"); handler.postDelayed(this, 1000) } }
    private val ocrReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_TEST_ALERT) { trigger("fatigue", "测试提醒：提示音、呼吸灯与顶部提示正常") ; return }
            val speed = intent?.getIntExtra(ScreenCaptureService.EXTRA_SPEED, -1) ?: -1
            val fuel = intent?.getIntExtra(ScreenCaptureService.EXTRA_FUEL_PERCENT, -1) ?: -1
            val detectedLimit = intent?.getIntExtra(ScreenCaptureService.EXTRA_LIMIT, -1) ?: -1
            if (intent?.hasExtra(ScreenCaptureService.EXTRA_GAME_ACTIVE) == true) {
                reminders.setGameActive(intent.getBooleanExtra(ScreenCaptureService.EXTRA_GAME_ACTIVE, false))
            }
            if (detectedLimit in 10..160) {
                currentDetectedLimit = detectedLimit
                currentLimitSource = intent?.getStringExtra(ScreenCaptureService.EXTRA_LIMIT_SOURCE) ?: "视觉估算"
            }
            if (speed >= 0) onSpeedRecognized(speed)
            if (fuel in 0..100 && reminders.onFuelPercent(fuel).fuelDue) trigger("fuel")
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        reminders = DrivingReminderController(this)
        tts = TextToSpeech(this, this)
        createChannel(); startForeground(9, notification()); registerOcrReceiver(); showOverlay()
        handler.post(fatigueTicker)
    }
    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale.SIMPLIFIED_CHINESE }
    private fun registerOcrReceiver() {
        val filter = IntentFilter(ScreenCaptureService.ACTION_OCR).apply { addAction(ACTION_TEST_ALERT) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(ocrReceiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(ocrReceiver, filter)
    }
    private fun onSpeedRecognized(speed: Int) {
        val limit = if (currentDetectedLimit in 10..160) currentDetectedLimit else prefs.getInt("manual_limit", prefs.getInt("highway_limit", 120))
        if (speed > limit) trigger("speed", "超速警告：当前 ${speed} km/h，限速 ${limit} km/h（${currentLimitSource}）") else clear("speed")
    }
    private fun trigger(type: String, custom: String? = null) {
        if (type in activeAlerts) {
            // Keep live speed values current while the overspeed condition remains active.
            if (type == "speed" && custom != null && pillAlertType == "speed") showPill(custom, false, "speed")
            return
        }
        activeAlerts.add(type)
        val label = custom ?: when(type) { "fuel" -> "燃油不足，请在下一个服务区补充燃油"; else -> "你可能已经疲劳，请在下一个服务区停下休息" }
        val lightKey = "${type}_light"; val soundKey = "${type}_sound"; val pillKey = "${type}_pill"
        if (prefs.getBoolean(soundKey, true) && ttsReady) tts?.speak(label, TextToSpeech.QUEUE_ADD, null, "ets3_$type")
        if (prefs.getBoolean(lightKey, true)) startRedPulse(type)
        if (prefs.getBoolean(pillKey, true) && prefs.getBoolean("bubble", true)) showPill(label, type == "fuel", type)
        if (type == "fuel") {
            fuelPillHideRunnable?.let { handler.removeCallbacks(it) }
            fuelPillHideRunnable = Runnable {
                if (pillAlertType == "fuel") {
                    pill?.visibility = View.GONE
                    pillAlertType = null
                }
                // Fuel alerts are edge-triggered and may fire again after the controller cooldown.
                activeAlerts.remove("fuel")
                if (activeAlerts.isEmpty()) stopRedPulse()
            }.also { handler.postDelayed(it, 5000) }
        }
    }
    private fun clear(type: String) {
        activeAlerts.remove(type)
        if (type == "fuel") {
            fuelPillHideRunnable?.let { handler.removeCallbacks(it) }
            fuelPillHideRunnable = null
        }
        if (activeAlerts.isEmpty()) stopRedPulse()
        if (pillAlertType == type) {
            pill?.text = "ETS3 · 辅助运行"
            pillAlertType = null
        }
    }
    private fun showPill(message: String, autoHide: Boolean, type: String) {
        pill?.let { it.text = message; it.visibility = View.VISIBLE }
        pillAlertType = type
        if (autoHide) {
            fuelPillHideRunnable?.let { handler.removeCallbacks(it) }
            fuelPillHideRunnable = Runnable {
                if (pillAlertType == type) {
                    pill?.visibility = View.GONE
                    pillAlertType = null
                }
            }.also { handler.postDelayed(it, 5000) }
        }
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ets3_assist", "欧洲卡3辅助运行", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ets3_assist") else Notification.Builder(this)
        return b.setContentTitle("欧洲卡3插件正在运行").setContentText("驾驶辅助提醒已启动").setSmallIcon(android.R.drawable.ic_dialog_info).build()
    }
    private fun params(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START): WindowManager.LayoutParams = WindowManager.LayoutParams(w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { this.gravity = gravity }
    private fun add(v: View, p: WindowManager.LayoutParams) { wm.addView(v, p); views.add(v) }
    private fun showOverlay() {
        if (prefs.getBoolean("bubble", true)) {
            pill = TextView(this).apply {
                text = "ETS3 · 辅助运行"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(22, 11, 22, 11)
                background = GradientDrawable().apply { setColor(0xdd171b22.toInt()); cornerRadius = 48f; setStroke(1, 0xff68717d.toInt()) }
                setOnClickListener { showQuickPanel() }
            }
            add(pill!!, params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { y = dp(8) })
        }
        leftEdge = View(this).apply { setBackgroundColor(Color.TRANSPARENT) }; rightEdge = View(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        add(leftEdge!!, params(dp(7), dp(240), Gravity.CENTER_VERTICAL or Gravity.START)); add(rightEdge!!, params(dp(7), dp(240), Gravity.CENTER_VERTICAL or Gravity.END))
    }
    private fun startRedPulse(type: String) {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0.10f, 0.88f).apply {
            duration = 850; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val alpha = (a.animatedValue as Float)
                val anyEnabled = activeAlerts.any { prefs.getBoolean("${it}_light", true) }
                val color = if (anyEnabled) Color.argb((alpha * 255).toInt(), 255, 0, 0) else Color.TRANSPARENT
                leftEdge?.setBackgroundColor(color); rightEdge?.setBackgroundColor(color)
            }; start()
        }
    }
    private fun stopRedPulse() { animator?.cancel(); animator = null; leftEdge?.setBackgroundColor(Color.TRANSPARENT); rightEdge?.setBackgroundColor(Color.TRANSPARENT) }
    private fun showQuickPanel() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 14); background = GradientDrawable().apply { setColor(0xf21b2029.toInt()); cornerRadius = 24f; setStroke(1, 0xff68717d.toInt()) } }
        panel.addView(TextView(this).apply { text = "欧洲卡3插件 · 控制面板"; textSize = 17f; setTextColor(Color.WHITE) })
        panel.addView(TextView(this).apply { text = "连续驾驶：${reminders.elapsedMinutes()} 分钟"; setTextColor(Color.WHITE) })
        panel.addView(Button(this).apply { text = "立即测试提醒（声音/灯光/顶部提示）"; setOnClickListener { trigger("fatigue", "测试提醒：提示音、呼吸灯与顶部提示正常") } })
        panel.addView(Button(this).apply { text = "停车休息并重置疲劳计时"; setOnClickListener { reminders.resetFatigue(); clear("fatigue"); Toast.makeText(this@OverlayService, "疲劳计时已重置", Toast.LENGTH_SHORT).show(); wm.removeView(panel); views.remove(panel) } })
        panel.addView(Button(this).apply { text = "暂停/继续疲劳计时"; setOnClickListener { val paused = prefs.getBoolean("fatigue_timer_running", true); reminders.pauseFatigue(paused); text = if (paused) "继续疲劳计时" else "暂停疲劳计时" } })
        panel.addView(Button(this).apply { text = "关闭面板"; setOnClickListener { try { wm.removeView(panel); views.remove(panel) } catch (_: Exception) {} } })
        add(panel, params(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { y = dp(58) })
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() {
        handler.removeCallbacks(fatigueTicker); fuelPillHideRunnable?.let { handler.removeCallbacks(it) }; try { unregisterReceiver(ocrReceiver) } catch (_: Exception) {}; stopRedPulse(); tts?.stop(); tts?.shutdown()
        views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; views.clear(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
