#!/usr/bin/env bash
set -u
echo "ETS3 Assistant build preflight"
if command -v java >/dev/null 2>&1; then java -version 2>&1 | head -n 1; else echo "FAIL: Java not found"; fi
if [ -n "${ANDROID_HOME:-}" ]; then echo "ANDROID_HOME=$ANDROID_HOME"; elif [ -n "${ANDROID_SDK_ROOT:-}" ]; then echo "ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"; else echo "MISSING: ANDROID_HOME / ANDROID_SDK_ROOT"; fi
if command -v gradle >/dev/null 2>&1; then gradle --version | head -n 8; else echo "MISSING: gradle executable (project has no Gradle Wrapper JAR)"; fi
if [ -n "${ANDROID_HOME:-}" ] && [ -f "$ANDROID_HOME/platforms/android-35/android.jar" ]; then echo "OK: Android 35 platform found"; else echo "MISSING: Android SDK Platform 35"; fi
