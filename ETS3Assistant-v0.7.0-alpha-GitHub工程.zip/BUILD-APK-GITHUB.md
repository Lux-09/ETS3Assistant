# 云端 APK 编译说明

本工程已附带 GitHub Actions 工作流：`.github/workflows/android-apk.yml`。

## 首次运行
1. 将 `ETS3Assistant` 文件夹中的全部内容上传到你自己的 GitHub 仓库根目录（仓库建议设为 Private）。
2. 打开仓库的 Actions 页面，本版本在提交到 `main` 后会自动触发 **Build Android APK**。
3. 等待任务完成。绿色成功后，在该次运行页面底部的 Artifacts 下载 `ETS3Assistant-debug-apk`。
4. 解压后得到 `app-debug.apk`，传到小米14安装测试。

## 说明
- 这是 Debug 测试包，不是正式签名发布包。
- 首次云端构建会下载 Gradle、Android SDK 和 Maven 依赖，需要等待。
- 如果构建失败，请把 Actions 页面中第一个红色步骤及错误日志发回，我会按日志修复。
- 工作流成功只代表编译通过，不代表游戏画面识别已经准确；仍需小米14实测。
