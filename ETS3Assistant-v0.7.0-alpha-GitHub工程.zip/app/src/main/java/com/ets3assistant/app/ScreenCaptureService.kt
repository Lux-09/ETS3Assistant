package com.ets3assistant.app

import android.app.*
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Experimental screen-capture/OCR pipeline.
 * MediaProjection consent is one-session only and must be requested again after a new session.
 */
class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        const val ACTION_OCR = "com.ets3assistant.app.OCR_RESULT"
        const val EXTRA_SPEED = "recognized_speed"
        const val EXTRA_FUEL_PERCENT = "recognized_fuel_percent"
        const val EXTRA_RAW = "recognized_text"
        const val EXTRA_LIMIT = "recognized_limit"
        const val EXTRA_LIMIT_SOURCE = "recognized_limit_source"
        const val EXTRA_SCENE = "recognized_scene"
        private const val CHANNEL = "ets3_capture"
        private const val NOTIFICATION_ID = 10
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val processing = AtomicBoolean(false)
    private val prefs by lazy { getSharedPreferences("ets3", MODE_PRIVATE) }
    private var lastProcessedAt = 0L
    private var screenWidth = 0
    private var screenHeight = 0
    private var density = 1
    private var lastSpeedCandidate = -1
    private var stableSpeedFrames = 0
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopSelf() }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        worker = HandlerThread("ets3-screen-ocr").also { it.start() }
        workerHandler = Handler(worker!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = getResultData(intent)
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf(); return START_NOT_STICKY
        }
        try {
            // A MediaProjection token is single-use on modern Android. Do not start a second
            // virtual display from the same service instance.
            if (projection != null) {
                broadcastStatus("屏幕采集已经运行；如需重新授权，请先停止并重新启动采集")
                return START_NOT_STICKY
            }
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else startForeground(NOTIFICATION_ID, notification())
            beginCapture(resultCode, data)
        } catch (e: Exception) {
            broadcastStatus("屏幕采集启动失败：${e.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getResultData(intent: Intent?): Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_RESULT_DATA)

    private fun beginCapture(resultCode: Int, data: Intent) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        density = metrics.densityDpi
        reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ source -> processLatest(source) }, workerHandler)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(projectionCallback, workerHandler)
        display = projection?.createVirtualDisplay("ETS3 Assistant Capture", screenWidth, screenHeight, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, workerHandler)
        broadcastStatus("屏幕采集已启动，正在分析画面")
    }

    private fun processLatest(source: ImageReader) {
        val image = try { source.acquireLatestImage() } catch (_: Exception) { null } ?: return
        val now = System.currentTimeMillis()
        if (now - lastProcessedAt < 900 || !processing.compareAndSet(false, true)) { image.close(); return }
        lastProcessedAt = now
        val bitmap = try { imageToBitmap(image) } catch (_: Exception) { null } finally { image.close() }
        if (bitmap == null) { processing.set(false); return }
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val positioned = result.textBlocks.mapNotNull { block -> block.boundingBox?.let { box ->
                    Triple(box, block.text, box.centerX().toFloat() / screenWidth)
                } }
                val rawSpeed = findSpeedCandidate(result.text, positioned.map { Triple(it.third, it.first.centerY().toFloat() / screenHeight, it.second) })
                val speed = if (rawSpeed != null && kotlin.math.abs(rawSpeed - lastSpeedCandidate) <= 3) {
                    stableSpeedFrames++
                    rawSpeed
                } else {
                    lastSpeedCandidate = rawSpeed ?: -1
                    stableSpeedFrames = if (rawSpeed != null) 1 else 0
                    null
                }.takeIf { stableSpeedFrames >= 2 }
                if (rawSpeed == null) { lastSpeedCandidate = -1; stableSpeedFrames = 0 }
                val fuelPercent = findFuelPercent(boxes = positioned.map { Triple(it.third, it.first.centerY().toFloat() / screenHeight, it.second) })
                // Road/sign recognition is intentionally disabled in this build. Use only the user's manual speed limit until a separate, validated source is implemented.
                val manualLimit = prefs.getInt("manual_limit", 120).coerceIn(10, 160)
                // Avoid broadcasting an empty OCR result every frame; scene/limit decisions are still
                // sent when OCR or the visual classifier has useful evidence.
                val hasUsefulSignal = speed != null || fuelPercent != null || result.text.isNotBlank()
                if (hasUsefulSignal) {
                    val event = Intent(ACTION_OCR).setPackage(packageName).putExtra(EXTRA_RAW, result.text)
                        .putExtra(EXTRA_LIMIT, manualLimit).putExtra(EXTRA_LIMIT_SOURCE, "手动限速")
                    if (speed != null) event.putExtra(EXTRA_SPEED, speed)
                    if (fuelPercent != null) event.putExtra(EXTRA_FUEL_PERCENT, fuelPercent)
                    sendBroadcast(event)
                }
            }
            .addOnFailureListener { broadcastStatus("OCR识别暂不可用") }
            .addOnCompleteListener { bitmap.recycle(); processing.set(false) }
    }

    /** Fuel OCR: accept only explicit percentage text near the annotated lower-left fuel/speed display. */
    private fun findFuelPercent(boxes: List<Triple<Float, Float, String>>): Int? {
        // Calibrated from the user screenshot (1536x690): annotated speed/fuel display is at
        // the lower-left edge, approximately x=.23-.34 and y=.88-.99.
        val roiText = boxes.filter { (x, y, _) -> x in 0.22f..0.36f && y in 0.86f..0.995f }
            .joinToString(" ") { it.third }
        val candidates = Regex("(?<!\\d)(100|[1-9]?\\d)\\s*%").findAll(roiText)
            .mapNotNull { it.groupValues[1].toIntOrNull() }.toList()
        return candidates.firstOrNull { it in 0..100 }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    /** Read speed only from the annotated lower-left speed display. Requires validation on live gameplay. */
    private fun findSpeedCandidate(fullText: String, boxes: List<Triple<Float, Float, String>>): Int? {
        val candidates = boxes.filter { (x, y, _) -> x in 0.22f..0.36f && y in 0.86f..0.995f }
            .flatMap { (_, _, text) -> Regex("(?<!\\d)(\\d{1,3})(?!\\d)").findAll(text).mapNotNull { it.groupValues[1].toIntOrNull() }.toList() }
            .filter { it in 0..180 }
        if (candidates.isNotEmpty()) return candidates.firstOrNull { it > 0 }
        // Do not guess from unrelated dashboard digits elsewhere on screen.
        return null
    }

    private fun broadcastStatus(message: String) {
        sendBroadcast(Intent(ACTION_OCR).setPackage(packageName).putExtra(EXTRA_RAW, message))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "ETS3屏幕识别", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(): Notification = Notification.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("欧洲卡3插件正在识别")
        .setContentText("屏幕采集已开启，返回游戏即可").setOngoing(true).build()

    override fun onDestroy() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.unregisterCallback(projectionCallback) } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { recognizer.close() } catch (_: Exception) {}
        worker?.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
