package com.ets3assistant.app

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import kotlin.math.max
import kotlin.math.min

/** Conservative visual limit engine. It never treats arbitrary dashboard digits as road signs. */
class SceneLimitEngine(private val prefs: android.content.SharedPreferences) {
    enum class Scene { CITY, ROAD, HIGHWAY, UNKNOWN }
    data class Decision(val scene: Scene, val limitKmh: Int, val signLimitKmh: Int?, val source: String, val confidence: Float)

    fun decide(bitmap: Bitmap, blocks: List<Triple<Rect, String, Float>>): Decision {
        val sign = if (prefs.getBoolean("game_signs", true)) findSpeedSign(bitmap, blocks) else null
        val scene = if (prefs.getBoolean("scene_speed", true)) classifyScene(bitmap, blocks.map { it.second }.joinToString(" ")) else Scene.UNKNOWN
        val sceneLimit = when (scene) {
            Scene.CITY -> prefs.getInt("city_limit", 70)
            Scene.ROAD -> prefs.getInt("road_limit", 90)
            Scene.HIGHWAY -> prefs.getInt("highway_limit", 120)
            Scene.UNKNOWN -> prefs.getInt("manual_limit", prefs.getInt("highway_limit", 120))
        }.coerceIn(10, 160)
        return if (sign != null) Decision(scene, sign, sign, "游戏限速标志", 0.78f)
        else Decision(scene, sceneLimit, null, if (scene == Scene.UNKNOWN) "手动默认限速" else "场景估算", if (scene == Scene.UNKNOWN) 0.35f else 0.48f)
    }

    /** Sign OCR must be in the forward-road region and surrounded by a red circular-sign-like ring. */
    private fun findSpeedSign(bitmap: Bitmap, blocks: List<Triple<Rect, String, Float>>): Int? {
        val candidates = blocks.mapNotNull { (rect, text, _) ->
            val normalizedY = rect.centerY().toFloat() / bitmap.height
            val normalizedX = rect.centerX().toFloat() / bitmap.width
            if (normalizedX !in 0.20f..0.80f || normalizedY !in 0.10f..0.62f) return@mapNotNull null
            val match = Regex("(?<!\\d)(30|40|50|60|70|80|90|100|110|120|130)(?!\\d)").find(text) ?: return@mapNotNull null
            val value = match.groupValues[1].toIntOrNull() ?: return@mapNotNull null
            if (hasRedRing(bitmap, rect)) value else null
        }
        return candidates.firstOrNull()
    }

    private fun hasRedRing(bitmap: Bitmap, rect: Rect): Boolean {
        val cx = rect.centerX(); val cy = rect.centerY()
        val radius = max(12, max(rect.width(), rect.height()) * 2)
        val left = max(0, cx - radius); val right = min(bitmap.width - 1, cx + radius)
        val top = max(0, cy - radius); val bottom = min(bitmap.height - 1, cy + radius)
        var red = 0; var sampled = 0
        val inner = max(3, radius / 3)
        for (y in top..bottom step 3) for (x in left..right step 3) {
            val dx = x - cx; val dy = y - cy; val d2 = dx * dx + dy * dy
            if (d2 < inner * inner || d2 > radius * radius) continue
            val c = bitmap.getPixel(x, y); sampled++
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            if (r > 145 && r > g * 1.35 && r > b * 1.25) red++
        }
        return sampled > 8 && red.toFloat() / sampled >= 0.055f
    }

    /**
     * Scene recognition is deliberately fail-safe in this alpha build.
     * Generic color ratios (green trees / grey buildings) are not reliable evidence
     * of road class in a game scene, so only explicit scene labels are accepted.
     * Otherwise UNKNOWN falls back to the user's configured manual limit.
     */
    private fun classifyScene(bitmap: Bitmap, ocrText: String): Scene {
        val text = ocrText.lowercase()
        return when {
            listOf("motorway", "autobahn", "highway", "高速").any { text.contains(it) } -> Scene.HIGHWAY
            listOf("city", "urban", "市区", "市中心").any { text.contains(it) } -> Scene.CITY
            listOf("rural", "country road", "乡村公路").any { text.contains(it) } -> Scene.ROAD
            else -> Scene.UNKNOWN
        }
    }

}
