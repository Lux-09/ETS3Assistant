# 欧洲卡3插件（ETS3 Assistant）

版本：`0.6.2-alpha`（源码预发布版）  
目标设备：小米14 / Android 16  
包名：`com.ets3assistant.app`

## 本轮变更（v0.6.2-alpha）
- 以 v0.6.1-alpha 工程为基线更新版本号。
- MediaProjection 服务增加重复启动保护，避免同一服务实例重复创建虚拟显示。
- 将 MediaProjection 回调保存为成员并在销毁时注销，完善资源生命周期。
- 保留悬浮辅助、疲劳计时、低油量阈值防抖、OCR 速度候选校验及实验性场景/限速牌判断。

## 重要限制
这仍是实验性源码，不是可用于真实驾驶的安全产品。当前识别准确率未经小米14真机验证：
- 速度识别依赖 OCR 与固定屏幕区域，可能漏检/误检。
- 燃油只接受仪表 ROI 中明确出现的百分比文字；若游戏显示的是指针油表，当前版本无法可靠读取。
- 限速牌识别依赖前景区域 OCR 数字与红色环形特征，未经过游戏内样本验证。
- 场景识别只是粗略像素启发式，不具备可靠道路语义识别能力；不确定时回退到手动限速。
- 疲劳计时是辅助服务运行时间的近似值，玩家需自行暂停/重置；它无法自动确认车辆已停车。
- 偏离路线、任务完成、真实弯道/匝道识别尚未实现。

## 构建要求
- JDK 17
- Android SDK Platform 35（Build Tools 35.x）
- Gradle 8.9 或兼容版本（Android Gradle Plugin 8.7.3）
- Android Studio 可联网下载插件和 ML Kit 依赖

工程当前未附 Gradle Wrapper。打开工程根目录后，在有 Gradle 的环境执行：

```bash
gradle assembleDebug
```

预期 APK 路径：`app/build/outputs/apk/debug/app-debug.apk`。本次运行环境只有 JDK 21，没有 Gradle 可执行文件、Gradle Wrapper 和 Android SDK，因此未能执行 Android 编译，也没有生成 APK。

## 首次真机测试建议
1. 安装 debug APK 后，允许“显示在其他应用上层”。
2. 启动悬浮辅助，再授权 MediaProjection 屏幕采集。
3. 返回游戏，先观察 OCR 原始结果，不要直接依赖自动限速。
4. 对照游戏仪表逐项验证速度、燃油和限速牌；出现误识别时关闭相应提醒。
5. 验证 Android 16 上前台服务通知、屏幕采集停止/重启、悬浮窗关闭与恢复。

**注意：** Android 14+ 的 MediaProjection 用户授权按会话管理；重新开始采集时应重新请求系统授权。


## v0.6.3-alpha 本次变更
- 场景限速改为保守策略：只接受明确的场景文字线索；无法确认时回退到用户设置的手动限速。
- 移除基于“绿色像植被/灰色像建筑”的颜色比例猜测，避免将普通道路误判为城市或高速。
- 这不代表场景识别已完成；游戏画面通常不会显示这些文字，因此大多数情况下会回退手动限速。

## 当前构建阻塞
本工作环境有 JDK 21，但没有 Gradle、Gradle Wrapper JAR、Android SDK 或 `android.jar`，并且当前容器 DNS 无法解析 Gradle/Google 下载站点。因此这里不能真实执行 Android 构建，也不能交付声称可安装的 APK。源码包不等于 APK。
